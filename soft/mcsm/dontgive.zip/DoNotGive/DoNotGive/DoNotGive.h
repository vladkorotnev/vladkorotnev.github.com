

#import <Cocoa/Cocoa.h>
#import "MCServManPlugin.h"
@interface DoNotGive : NSObject <MCServManPlugin>

@end

	
